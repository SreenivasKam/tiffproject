#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>

//----------------- Global Variables  --------------------------

// Variables used in tiff Image data extraction

// Structure to store the Extracted tiff file header.
struct TIFF_header
{
    short int format;
    short int arb;
    int offset;
};

// Structure to store the values for the Fields present in a Single IFD Entry of a tiff file.
struct IFD_entry
{
    short int tag,field_type;
    int field_count,value_offset;
    int *data;
};

// Structure to store Information about an Entire IFD which consists of the following
// 1. How many tags are present in the IFD
// 2. Array of all the tags and its details.
// 3. Offset to the next IFD.
struct IFD
{
    short int entry_count;
    struct IFD_entry *ifd_entry;
    int next_ifd_offset;
};

struct TIFF_header h;
struct IFD ifd1;

//Variables used to store the respective index position to access details about the tags from the IFD variable that has the extracted data.
int Newsubfile_type,img_w,img_l,bps,compression,photometric_int,strip_off,samples_per_pixel,rows_per_strip,strip_byte_count,xres,yres,resoultion_unit;

// Variables used for 1D encoding

// Structure to store the Number of Alternating runs present in a single Scan line of the Image and their respective runlengths.
// Note the First run in all scan lines represent a run of White Pixels. 
struct runlength
{
    int *runlength;
    int run_count;
};

// Structure used to store the Huffman runlength table. It maps a Runlength to its respective Codeword.
typedef struct codewords
{
    int runlen;
    char cw[25];

}cw;

// Structure to store returned file pointer and amount of bytes written into the encoded txt file after each write operation.
struct cmp_len
{
    FILE *cmp;                  //Pointer to write the encoded data;
    int byte_len;
};


struct runlength temprl[8000];

int capacity = 64;
int capacity_mu = 40;
cw *table_wt[64],*table_bt[64];
cw *table_wmu[40],*table_bmu[40];
char en_data_b[50];
char en_data_w[50];


//------------------------------ Function Definitions  --------------------------

//Functions - For tiff Image extraction

/*-------------------------------------------------------------------------
Function Name: extract_tiff_tags

Description : This function is used to Extract all the tags and other 
parameters of the Image file directory from the tiff file and store them in a structure.

Input Arguments: File pointer to the uncompressed tiff file.

Return Value: None - (Void)
---------------------------------------------------------------------------*/
void extract_tiff_tags(FILE* fp)
{
    // Extracting the header
    fread(&h,sizeof(struct TIFF_header),1,fp);
    printf("--------------------- Header Info : --------------------- \n");
    printf(" Format : %d\n",h.format);
    printf(" Arbitrary value : %d\n",h.arb);
    printf(" Offset: %d\n",h.offset);
    
    fseek(fp,h.offset,SEEK_SET);// Moving the pointer to the First IFD.

    // Extracting First IFD
    // Extracting - number of Entries in the IFD
    fread(&ifd1.entry_count,2,1,fp);
    // Allocating memory for the IFD entries and reading them
    ifd1.ifd_entry = (struct IFD_entry*)malloc(ifd1.entry_count * sizeof(struct IFD_entry));
    for(int i =0 ; i < ifd1.entry_count;i++)
    {
        fread(&ifd1.ifd_entry[i],12,1,fp);
    }
    // Extracting the offset to the next IFD
    fread(&ifd1.next_ifd_offset,4,1,fp);
    
    // Printing the extracted tags from the IFD
    printf("------------------------ IFD 1 ------------------------ : \n");
    printf(" No. of Entries : %d\n",ifd1.entry_count);
    for(int i = 0;i<ifd1.entry_count;i++)
    {
        printf("          ------ Ifd entry %d------\n",i+1);
        printf(" Tag : %d \n",ifd1.ifd_entry[i].tag);
        printf(" Field Type : %d \n",ifd1.ifd_entry[i].field_type);
        printf(" Field count : %d \n",ifd1.ifd_entry[i].field_count);
        
        if (ifd1.ifd_entry[i].field_count*ifd1.ifd_entry[i].field_type <= 4)
        {
            printf(" Field Value : %d \n",ifd1.ifd_entry[i].value_offset);
            ifd1.ifd_entry[i].data = (int*)malloc(ifd1.ifd_entry[i].field_count*ifd1.ifd_entry[i].field_type);
            for(int j = 0; j < ifd1.ifd_entry[i].field_count-1; j++)
            {
                ifd1.ifd_entry[i].data[j] = ifd1.ifd_entry[i].value_offset;
            }
            
        }
        else
        {
            printf(" Field Offset : %d \n",ifd1.ifd_entry[i].value_offset);
            fseek(fp,ifd1.ifd_entry[i].value_offset,SEEK_SET);
            ifd1.ifd_entry[i].data = (int*)malloc(ifd1.ifd_entry[i].field_count*ifd1.ifd_entry[i].field_type);
            //ifd1.ifd_entry[i].data[0] = 21;
            //printf("  @@@@@@@@@@ %d @@@@@@@@@ \n",ifd1.ifd_entry[i].data[0]);
            
            printf(" Field Values : ");
            for(int j = 0; j < ifd1.ifd_entry[i].field_count-1; j++)
            {
                fread(&ifd1.ifd_entry[i].data[j],4,1,fp);
                printf("%d , ",ifd1.ifd_entry[i].data[j]);
            }
            fread(&ifd1.ifd_entry[i].data[ifd1.ifd_entry[i].field_count-1],4,1,fp);
            printf("%d \n",ifd1.ifd_entry[i].data[ifd1.ifd_entry[i].field_count-1]);

        }
        switch (ifd1.ifd_entry[i].tag)
        {
            case 254: Newsubfile_type = i; break;
            case 256: img_w = i; break;
            case 257: img_l = i; break;
            case 258: bps = i; break;
            case 259: compression = i; break;
            case 262: photometric_int = i; break;
            case 273: strip_off = i; break;
            case 277: samples_per_pixel = i; break;
            case 278: rows_per_strip = i; break;
            case 279: strip_byte_count = i; break;
            case 282: xres = i; break;
            case 283: yres = i; break;
            case 296: resoultion_unit = i; break;
            default:break;
        }
        
    }

    printf("\n Next IFD offset %d\n",ifd1.next_ifd_offset);
    
    fclose(fp);

}

/*-------------------------------------------------------------------------
Function Name: extract_tiff_image

Description : This function uses the extracted tags that are stored in a 
structure variable to retrieve the actual image data. The Image data is 
extracted using the strip offsets and strip byte count tags. The Extracted 
Image data is stored in the form of a binary text file (img_bin.txt), 
Where each line has the same number of characters specified in the Image width tag. 

Input Arguments: This function uses two Input arguments.
                1. File pointer to the uncompressed tiff file.
                2. File pointer to a new empty text file where the 
                   Image data will be duped.

Return Value: None - (Void)
---------------------------------------------------------------------------*/
void extract_tiff_image(FILE* fp , FILE* img_bin)
{
    //char *data;
    //int c;
    char ch;
    int count = 0;
    //data = (int*)malloc(ifd1.ifd_entry[strip_off].field_count*1)
    //printf("\n\n ############ %d #############\n",ifd1.ifd_entry[img_w].value_offset);
    for(int i = 0 ; i < ifd1.ifd_entry[strip_off].field_count ; i++ )
    {
        //printf( "\n---------- %d ---------- %d ----------------\n\n",ifd1.ifd_entry[strip_off].data[i],ifd1.ifd_entry[strip_byte_count].data[i]);
        //data = (char*)malloc(ifd1.ifd_entry[strip_byte_count].data[i]);
        fseek(fp,ifd1.ifd_entry[strip_off].data[i],SEEK_SET);             //seek to the required offset
        for(int j = 0;j < ifd1.ifd_entry[strip_byte_count].data[i] ;j++)
        {
            if(count<ifd1.ifd_entry[img_w].value_offset)
            {
                ch = fgetc(fp);
                count++;
                if(ch == -1)
                    fputc('1',img_bin);
                else
                    fputc('0',img_bin);
            //printf("%d",ch);  
            }
            else
            {
                fputc('\n',img_bin);
                count = 0;
                j = j-1;
            }
            
        }
        
        //fread(&data,ifd1.ifd_entry[strip_byte_count].data[i],1,fp);
        //printf("\n\n%s\n\n", data);
        //fprintf(img_bin, "%s", data);
    
    }
    fclose(fp);
    fclose(img_bin);
  
}

// Functions used for 1D encoding

//Runlength function

/*-------------------------------------------------------------------------
Function Name: run_length

Description : This function Stores the Number of Alternating runs Present 
in each scan line and their respective run lengths in an array of structure
variables of the type struct runlength.

Input Arguments: File pointer to the text file which has the uncompressed 
Image data (img_bin.txt)

Return Value: Returns a pointer to the structure variable array that stores
the run lengths for each scan line.
---------------------------------------------------------------------------*/
struct runlength* run_length(FILE *ptr)
{
    
    int c;
    int flag1 = 1;
    int line = 1;
    //printf(" \n@@@@@@@@@@@ %d @@@@@@@@",ifd1.ifd_entry[img_w].value_offset);
    int img_w_rl = (int)ifd1.ifd_entry[img_w].value_offset + 1;
    int temp=0;
    int count = 0;
    int temp_count = 0;

    while(flag1)
    {   
        //printf(" \n\n LINE NUMBER   ::  %d \n\n",line);
        //int flag2 = 1;
        temp=0;
        count = 0;
        temp_count = 0;
        //if(line != 1)
            //c = fgetc(ptr);
        temprl[line-1].run_count=1;
        if (ptr == NULL)
        {
            printf("File is not available \n");
        }
        else
        {   
            c = fgetc(ptr) - '0';
            temp_count = temp_count + 1;
            if(c == 0)
            {
                temp = c;
                //printf(" %d -->",count);
                temprl[line-1].runlength = (int*)malloc(sizeof(int)*temprl[line-1].run_count);
                temprl[line-1].runlength[temprl[line-1].run_count-1] = count;
                temprl[line-1].run_count = temprl[line-1].run_count +1;
                count = count + 1;
            }
            else
            {
                temp = c;
                temprl[line-1].runlength = (int*)malloc(sizeof(int)*temprl[line-1].run_count);
                count = count + 1;
            }

            while ((c = fgetc(ptr)) != EOF && temp_count+1 < img_w_rl)
            {   
                c = c - '0';
                temp_count = temp_count + 1;
                
                if(c != temp)
                {
                    //printf(" %d -->",count);
                    temprl[line-1].runlength = realloc(temprl[line-1].runlength,sizeof(int)*temprl[line-1].run_count);
                    temprl[line-1].runlength[temprl[line-1].run_count-1] = count;
                    temprl[line-1].run_count = temprl[line-1].run_count +1;
                    count = 1;
                    temp = c;
                }
                else
                {
                    count+=1;
                }
            }
            //printf(" %d ",count);
            temprl[line-1].runlength = realloc(temprl[line-1].runlength,sizeof(int)*temprl[line-1].run_count);
            temprl[line-1].runlength[temprl[line-1].run_count-1] = count;
            if(temp_count == img_w_rl-1 && c != EOF)
                line = line + 1;
            else if(c == EOF)
                flag1 = 0; 
        }
    }
    return temprl;
}

/*-------------------------------------------------------------------------
Function Name: insert

Description : Function used to insert the key value pair in a structure. 
It also chooses which table to fill the runlength and its respective codeword.
It finally creates 4 tables - Make up and terminal huffman tables for white 
and black pixel runs.

Input Arguments: Four Arguments
                 1. Key - It stands for the runlength.
                 2. data - It is the corresponding codeword for the respective 
                 runlength
                 3. table - It indicates which table the Key-Value pair should 
                 be written in.
                 4. ind - It has the index value for where the Key value pair 
                 should be inserted in the respective table.

Return Value: None - (Void)
---------------------------------------------------------------------------*/
void insert(int key,char *data,int table,int ind) 
{
    cw *temp = (cw*) malloc(sizeof(cw));
    strcpy(temp->cw,data);  
    temp->runlen = key; 
   
    switch(table)
    {
        case 1: table_wt[ind] = temp; break;
        case 2: table_bt[ind] = temp; break;
        case 3: table_wmu[ind] = temp; break;
        case 4: table_bmu[ind] = temp; break;
    } 
}

/*-------------------------------------------------------------------------
Function Name: insert_values        

Description : This function retrieves the key value and the corresponding 
Key word from the text fill with the Huffman codewords.

Input Arguments: Two input arguments
                 1. A character string that has a file name from which the 
                 huffman codes will be read
                 2. table - It indicates which table the Key-Value pair should 
                 be written in. It also helps decide how many iterations the 
                 for loop shoud run in order to read the entire file.

Return Value: None - (Void)
---------------------------------------------------------------------------*/
void insert_values(char *filename,int table)
{
    int r; char c[25];
    char str[100];
    int temp_capacity;
    if (table == 1 || table == 2)
        temp_capacity = capacity;
    else
        temp_capacity = capacity_mu;
    
    FILE *ptr=fopen(filename,"r");

    if(ptr==NULL)
        printf("File does not exist!");
    else
    {
        for(int i=0;i<temp_capacity;i++)
        {
            fscanf(ptr,"%d",&r);
            fscanf(ptr,"%s",&c);
            insert(r,c,table,i);
            fgets(str,100,ptr);
        }
    }
    fclose(ptr);
}

/*-------------------------------------------------------------------------
Function Name: display

Description : This function is used to print the huffman codes after they
are stored as a form of an array of structures. It is used to verify is the 
tables are properly stored.

Input Arguments: None

Return Value: None - (Void)
---------------------------------------------------------------------------*/
void display() 
{   
    int choice;
    printf("\n [0] -> white table(Terminal)\n [1] -> Black table(Terminal)\n [2] -> white table(Makeup)\n [3] -> Black table(Makeup) \n Please Enter choice :  ");
    scanf("%d",&choice);
    
    if(choice == 0) 
    {
        int i = 0;
        for(i = 0; i<capacity; i++)
        {
            if(table_wt[i] != NULL)
                printf(" (%d,%s) \n",table_wt[i]->runlen,table_wt[i]->cw);
            else
                printf(" ~~\n ");
        }
        printf("\n");
    }
    else if (choice == 1)
    {
       int i = 0;
       for(i = 0; i<capacity; i++)
        {
            if(table_bt[i] != NULL)
                printf(" (%d,%s) \n",table_bt[i]->runlen,table_bt[i]->cw);
            else
                printf(" ~~\n ");
        }
        printf("\n");
    }
    else if (choice == 2)
    {
       int i = 0;
       for(i = 0; i<capacity_mu; i++)
        {
            if(table_wmu[i] != NULL)
                printf(" (%d,%s) \n",table_wmu[i]->runlen,table_wmu[i]->cw);
            else
                printf(" ~~\n ");
        }
        printf("\n");
    }
    else if (choice == 3)
    {
       int i = 0;
       for(i = 0; i<capacity_mu; i++)
        {
            if(table_bmu[i] != NULL)
                printf(" (%d,%s) \n",table_bmu[i]->runlen,table_bmu[i]->cw);
            else
                printf(" ~~\n ");
        }
        printf("\n");
    }
    else
    {
        printf("\n Please enter correct choice \n");
        display();
    }
        
}

//Creating the huffman codeword - Hash tables
/*-------------------------------------------------------------------------
Function Name: terminal_cw_gen

Description : Its job is to call the insert_values function with the right 
parameters for generating the terminal code words table. It specifies the 
right file name to read the huffman terminal codewords and the right table 
to insert them in.

Input Arguments: None

Return Value: None - (Void)
---------------------------------------------------------------------------*/
void terminal_cw_gen()
{
    char filename_w[]="terminal_cw_w.txt";
    char filename_b[]="terminal_cw_b.txt";
    
    
    insert_values(filename_w,1);
    insert_values(filename_b,2);
    //display();
}

/*-------------------------------------------------------------------------
Function Name: makeup_cw_gen

Description : Its job is to call the insert_values function with the right 
parameters for generating the makeup code words table. It specifies the 
right file name to read the huffman makeup codewords and the right table 
to insert them in.

Input Arguments: None

Return Value: None - (Void)
---------------------------------------------------------------------------*/
void makeup_cw_gen()
{
    char filename_w[]="makeup_cw_w.txt";
    char filename_b[]="makeup_cw_b.txt";

    insert_values(filename_w,3);
    insert_values(filename_b,4);
    //display();
}

/*-------------------------------------------------------------------------
Function Name: search_w

Description : Its job is to retrive the correct codeword for the runlength
key given for a run of white pixels. It uses both make up and the terminal 
codeword tables to find the right codeword for the runlength. Once it finds
the codeword it returns a pointer to a character array that has the correct 
codeword for the Key. 

Input Arguments: Key - It is the runlength value for which a codeword has 
to be found

Return Value: Pointer to a character array that stores the respective 
codeword.
---------------------------------------------------------------------------*/
char* search_w(int key)
{
    //char en_data[50];
    int m,t;
    int i = 0;
   
    if (key > 63)
    {
        m = key/64;
        t = key%64;

        //printf("\n -   -   -   - %d -  -   -   -",m*64);
        //printf("\n -   -   -   - %d -  -   -   -",t);
        
        while(table_wmu[i]->runlen != m*64)
        {
            i = i+1;
        }
        //printf("\n -   -   -   - %s -  -   -   -",table_wmu[i]->cw);
        strcpy(en_data_w,table_wmu[i]->cw);
        i = 0;
        while(table_wt[i]->runlen != t)
        {
            i = i+1;
        }
        //printf("\n -   -   -   - %s -  -   -   -",table_wt[i]->cw);
        strcat(en_data_w,table_wt[i]->cw);
        //printf("\n Search output :  %s ",en_data_w);

    }
    else
    {
        while(table_wt[i]->runlen != key)
        {
            i = i+1;
        }
        //printf("\n -   -   -   - %s -  -   -   -",table_wt[i]->cw);
        strcpy(en_data_w,table_wt[i]->cw);
        //printf("\n Search output :  %s ",en_data_w);
    }
    return en_data_w;

}

/*-------------------------------------------------------------------------
Function Name: search_b

Description : Its job is to retrive the correct codeword for the runlength
key given for a run of black pixels. It uses both make up and the terminal 
codeword tables to find the right codeword for the runlength. Once it finds
the codeword it returns a pointer to a character array that has the correct 
codeword for the Key. 

Input Arguments: Key - It is the runlength value for which a codeword has 
to be found

Return Value: Pointer to a character array that stores the respective 
codeword.
---------------------------------------------------------------------------*/
char* search_b(int key)
{
    //char en_data_b[50];
    int m,t;
    int i = 0;
   
    if (key > 63)
    {
        m = key/64;
        t = key%64;

        //printf("\n -   -   -   - %d -  -   -   -",m*64);
        //printf("\n -   -   -   - %d -  -   -   -",t);
        
        while(table_bmu[i]->runlen != m*64)
        {
            i = i+1;
        }
        //printf("\n -   -   -   - %s -  -   -   -",table_wmu[i]->cw);
        strcpy(en_data_b,table_bmu[i]->cw);
        i = 0;
        while(table_bt[i]->runlen != t)
        {
            i = i+1;
        }
        //printf("\n -   -   -   - %s -  -   -   -",table_wt[i]->cw);
        strcat(en_data_b,table_bt[i]->cw);
        //printf("\n Search output :  %s ",en_data_b);
        
    }
    else
    {
        while(table_bt[i]->runlen != key)
        {
            i = i+1;
        }
        //printf("\n -   -   -   - %s -  -   -   -",table_wt[i]->cw);
        strcpy(en_data_b,table_bt[i]->cw);
        //printf("\n Search output :  %s ",en_data_b);
        
    }
    return en_data_b;
}

/*-------------------------------------------------------------------------
Function Name: encode_1d

Description : This function is used to Identify if a runlength value belongs
white pixels or black pixels , then call the search_w or search_b pixel 
accordingly to find the codeword.

Input Arguments: Two arguments
                 1. Variable of type Struct cmp_len - Structure that stores 
                 pointer location to file for writing into the compressed 
                 encoded text file and also the number of bytes written 
                 into the file.
                 2. Variable of type struct runlength - It stores the number of 
                 runlengths and the size of each run for which the appropriate
                 codewords must be found.

Return Value: It returns a variable of type struct cmp_len which is used to 
store the current pointer location and also the number of bytes written into 
the file. It helps us determine the number of fill bits that need to be 
inserted at different locations in the compressed text file.
---------------------------------------------------------------------------*/
struct cmp_len encode_1d(struct cmp_len cl,struct runlength rl)
{
    int i = 0;
    int count = 0;
    cl.byte_len = 0;
    //printf(" \n ENCODE START ");
    for(i = 0; i < rl.run_count ; i++)
    {
        if( i%2 == 0)
        {
            count = fprintf(cl.cmp , search_w(rl.runlength[i]) );
        }
        else
        {
            count = fprintf(cl.cmp , search_b(rl.runlength[i]) );
        }
        cl.byte_len = cl.byte_len + count;
    }

    return cl; 

}

int main()
{
    printf("\n Image Extraction Started \n");
    FILE *fp = fopen("sample_uc.tiff","rb");  // Pointer to the Uncompressed tiff file opened in read mode.
    extract_tiff_tags(fp);

    // ********************************************************************************

    fp = fopen("sample_uc.tiff","rb");          // Pointer to the Uncompressed tiff file opened in read mode.
    FILE *img_bin = fopen("img_bin.txt","wb");  // Pointer to a new empty textfile opened in write mode to dump the Image data.
    extract_tiff_image(fp,img_bin);
    printf(" \n************************************** Extraction Done **************************************");
    printf(" \n                           Extracted Image stored in img_bin.txt          \n\n");

    printf(" \n --> Starting 1D compression !!");
    FILE *txt;                      
  
    struct cmp_len cl;                      
    struct runlength *rl;
    int j;
    int fill_bit_len = 0;          //Variable to store Number of fillbits required before each EOL 
    
    txt = fopen("img_bin.txt","rb");    //Pointer to text file that contains the extracted image data opened in read mode
    cl.cmp = fopen("encoded_img_bin.txt","wb"); //  Pointer to a new empty textfile opened in write mode to dump the compressed 1D encoded image data.

    rl = run_length(txt);

    /*
    for(int j = 0 ; j < 2560 ; j++)
    {
        printf(" \n LINE - %d :  \n ",j+1);
        for(int i = 0;i < rl[j].run_count-1;i++)
        {
            printf(" %d -->",rl[j].runlength[i]);
        }
        printf(" %d",rl[j].runlength[rl[j].run_count-1]);
        printf("\n");
    }
    */

    terminal_cw_gen();
    makeup_cw_gen();

    //display();
    

    //search_b(2);
    //search_b(400);
    // -------------------- Writing the Encoded data into a file ----------------------
    fputs("0000000000000001",cl.cmp);
    for(j = 0 ; j < 2559 ; j++)
    {
        //fprintf(cmp," \n Line number %d : \n ",j+1);
        cl = encode_1d(cl,rl[j]);
        //
        fill_bit_len = (cl.byte_len + 12) % 8; // +12 for EOL
        fill_bit_len = 8 - fill_bit_len;
        for(int c = 0 ; c < fill_bit_len ; c++)
        {
            fputs("0",cl.cmp);
        }
        fputs("000000000001",cl.cmp);//
    }
    //fprintf(cmp," \n Line number %d : \n ",j+1);
    cl = encode_1d(cl,rl[j]);
    //
    fill_bit_len = (cl.byte_len + 12*6) % 8;
    fill_bit_len = 8 - fill_bit_len;
    for(int c = 0 ; c < fill_bit_len ; c++)
    {
        fputs("0",cl.cmp);
    }
    fputs("000000000001000000000001000000000001000000000001000000000001000000000001",cl.cmp);//
    
    fclose(txt);
    fclose(cl.cmp);
    printf("\n\n*************************** COMPRESSION SUCCESSFULLY COMPLETED:) ***************************");
    printf("\n\n NOTE : - Compressed Image data stored in encoded_img_bin.txt \n\n");

    return 0;

}
